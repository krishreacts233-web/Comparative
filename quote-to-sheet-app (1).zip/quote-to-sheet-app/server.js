// Quote-to-Sheet backend
// Holds the Anthropic API key server-side and proxies extraction requests
// from the browser, so the key is never exposed to the client.

const express = require("express");
const path = require("path");

const app = express();
app.use(express.json({ limit: "25mb" })); // quotes can include base64 PDFs/images

const PORT = process.env.PORT || 3000;
const API_KEY = process.env.ANTHROPIC_API_KEY;

if (!API_KEY) {
  console.warn(
    "\n⚠  ANTHROPIC_API_KEY is not set.\n" +
      "   Set it before starting the server, e.g.:\n" +
      "   ANTHROPIC_API_KEY=sk-ant-... npm start\n"
  );
}

app.use(express.static(path.join(__dirname, "public")));

app.post("/api/extract", async (req, res) => {
  if (!API_KEY) {
    return res.status(500).json({ error: "Server is missing ANTHROPIC_API_KEY." });
  }
  const { contentBlocks } = req.body || {};
  if (!contentBlocks) {
    return res.status(400).json({ error: "Missing contentBlocks in request body." });
  }

  try {
    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": API_KEY,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 2000,
        system:
          "You extract structured pricing data from a vendor quotation (PDF, scanned photo, or text pulled from a Word document). " +
          "Respond with ONLY a single JSON object, no markdown fences, no commentary, matching exactly this shape:\n" +
          '{"vendor_name": string, "items": [{"description": string, "uom": string, "qty": number|null, "rate": number|null}], ' +
          '"gst_percent": number|null, "price_basis": string|null, "transit_insurance": string|null, "freight": string|null, ' +
          '"delivery_period": string|null, "payment_terms": string|null, "offer_number": string|null, "offer_date": string|null, ' +
          '"contact_person": string|null, "contact_no": string|null}\n' +
          "If a field truly isn't present in the document, use null. Numbers must be plain numbers (no currency symbols or commas). " +
          "vendor_name should be the supplier/company name issuing the quote, not the buyer.",
        messages: [{ role: "user", content: contentBlocks }],
      }),
    });

    if (!response.ok) {
      const text = await response.text().catch(() => "");
      return res.status(response.status).json({ error: `Anthropic API error: ${text.slice(0, 300)}` });
    }

    const data = await response.json();
    const textBlock = (data.content || []).find((b) => b.type === "text");
    if (!textBlock) {
      return res.status(502).json({ error: "No text content in Anthropic response." });
    }
    const cleaned = textBlock.text.replace(/```json/gi, "").replace(/```/g, "").trim();
    let parsed;
    try {
      parsed = JSON.parse(cleaned);
    } catch (e) {
      return res.status(502).json({ error: "Could not parse extraction result as JSON." });
    }
    res.json(parsed);
  } catch (err) {
    res.status(500).json({ error: err.message || "Extraction failed." });
  }
});

app.listen(PORT, () => {
  console.log(`Quote-to-Sheet running at http://localhost:${PORT}`);
});
