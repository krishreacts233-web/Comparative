# Quote-to-Sheet

Upload vendor quotes (PDF, Word, or a photo) and it auto-fills a comparative
statement, which you can export as an Excel file.

## Setup

You need [Node.js](https://nodejs.org) 18 or newer, and an Anthropic API key
from https://console.anthropic.com/settings/keys

```bash
cd quote-to-sheet-app
npm install
```

## Run

**Mac/Linux:**
```bash
ANTHROPIC_API_KEY=sk-ant-your-key-here npm start
```

**Windows (PowerShell):**
```powershell
$env:ANTHROPIC_API_KEY="sk-ant-your-key-here"; npm start
```

Then open **http://localhost:3000** in your browser.

## How it works

- `public/index.html` — the app itself (upload, table, Excel export). Runs entirely
  in your browser.
- `server.js` — a small Express server. It holds your API key and forwards
  extraction requests to Anthropic on the browser's behalf, so the key is
  never exposed to anyone loading the page.

## Deploying it somewhere real (so others can use it too)

This is a normal Node.js app, so it runs on any host that runs Node — Render,
Railway, Fly.io, a VPS, etc. The only thing you must do on whatever host you
pick is set the `ANTHROPIC_API_KEY` environment variable in that host's
settings (never commit it into the code or a public repo).

## Notes

- Your quote data is saved in the browser's local storage on whatever device
  you're using it from — it isn't synced anywhere.
- Every extracted value is editable in the table before you export, since
  extraction quality depends on how clean the source document is.
